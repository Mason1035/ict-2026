# PRE_B_TRAINING_CONTRACT v1.0

队员 A 的首版训练数据契约和合成数据生成器。完整冻结项见 [TRAINING_CONTRACT.md](TRAINING_CONTRACT.md)。

**PyCharm：** 用 PyCharm 打开本目录，选择 Python 3.11+，运行 `synthetic_dataset.py`。不需要安装第三方依赖。默认加载同级目录下 `../队员B_算法开发交付/risk_algorithm.py` 和 `demo_rules.json`，输出放在 `artifacts/pre_b_training_contract/`。

如 B 算法包位置不同，可设置 PyCharm Run Configuration 的 Script parameters：

```text
--algorithm-dir "E:\华为ict大赛\队员B_算法开发交付" --groups-per-class 60 --seed 20260925
```

输出包含 `train.csv`、`validation.csv`、`test.csv`、`dataset_all.csv`、unknown 排除台账、原始窗口审计 JSONL 和运行摘要。训练输入只能由程序 `FEATURES` 指定的四列组成，不能把标注或节点/时间/电量元数据作为特征。

本包**不训练模型**。标签由 B 演示规则生成，只能用来验证/拟合规则行为；全部是合成数据，不能解释成真实地灾样本或预测准确率。指标已经冻结，但此阶段 `model_metrics` 留空。
